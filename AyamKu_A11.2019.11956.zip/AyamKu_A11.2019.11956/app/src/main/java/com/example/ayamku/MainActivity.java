package com.example.ayamku;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterRcyclerView.OnNoteListener {

    RecyclerView recyclerView;
    AdapterRcyclerView adapterRcyclerView;
    RecyclerView.LayoutManager layoutManager;
    ArrayList<ItemModel> data;

    public TextView harga;
    public TextView total_harga;
    public int total_harga_Integer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        harga = findViewById(R.id.hargaAyam);
        total_harga = findViewById(R.id.TotalHarga);
        total_harga_Integer = 0;

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);

        layoutManager = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(layoutManager);

        data = new ArrayList<>();
        for (int i = 0; i< MenuAyam.nama.length; i++){
            data.add(new ItemModel(
                    MenuAyam.nama[i],
                    MenuAyam.harga[i],
                    MenuAyam.gambar[i]
            ));
        }
        adapterRcyclerView = new AdapterRcyclerView(data,this);
        recyclerView.setAdapter(adapterRcyclerView);
    }


    @Override
    public void onNoteClick(int position) {
        int i = Integer.parseInt(MenuAyam.harga[position]);
        total_harga_Integer = total_harga_Integer+i;
        total_harga.setText("Total Harga = RP."+total_harga_Integer);
    }
}
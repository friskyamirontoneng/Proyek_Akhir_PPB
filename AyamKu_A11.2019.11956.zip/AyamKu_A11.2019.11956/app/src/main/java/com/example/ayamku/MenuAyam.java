package com.example.ayamku;

public class MenuAyam {

    static int[] gambar ={
            R.drawable.ayam1,R.drawable.ayam2,R.drawable.ayam3,
            R.drawable.ayam4,R.drawable.ayam5,R.drawable.ayam6
    };

    static String[] nama ={
            "Ayam Goreng A","Ayam Goreng B","Ayam Goreng C",
            "Ayam Goreng D","Ayam Goreng E","Ayam Goreng F"
    };

    static String[] harga ={
            "10000","11000","11500",
            "12000","12500","13000"
    };
}
